﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace prjCreateTileDef {
	class Program {
		const string sID = @"D:\静岡大学\2022\QGISタイルレイヤ\dat";
		const string sOD = @"D:\静岡大学\2022\QGISタイルレイヤ";
		const string sFMT = "\t<xyztiles username=\"\" password=\"\" tilePixelRatio=\"0\" name=\"{0}\" url=\"{1}\" zmin=\"{2}\" zmax=\"{3}\" referer=\"\" authcfg=\"\"/>";

		static void Main(string[] args) {
			Encoding sjis = Encoding.GetEncoding(932);

			string[] sIn = Directory.GetFiles(sID, "*.tsv");
			for(int i=0; i < sIn.Length; i++) {
				string sOF = Path.Combine(sOD, Path.GetFileNameWithoutExtension(sIn[i]) + ".xml");
				using (StreamReader sr = new StreamReader(sIn[i], sjis))
				using (StreamWriter sw = new StreamWriter(sOF, false, Encoding.UTF8)) {
					sr.ReadLine();
					sw.WriteLine("<!DOCTYPE connections>");
					sw.WriteLine("<qgsXYZTilesConnections version=\"1.0\">");
					while (!sr.EndOfStream) {
						string[] sL = sr.ReadLine().Split('\t');
						sw.WriteLine(string.Format(sFMT, sL[0], sL[1], sL[2], sL[3]));
					}
					sw.WriteLine("</qgsXYZTilesConnections>");
				}
			}


		}
	}
}
